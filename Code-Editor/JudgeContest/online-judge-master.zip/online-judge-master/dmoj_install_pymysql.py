import pymysql

pymysql.install_as_MySQLdb()
pymysql.version_info = (1, 4, 0, 'final', 0)
